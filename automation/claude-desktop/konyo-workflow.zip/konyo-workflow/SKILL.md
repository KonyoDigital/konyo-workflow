---
name: konyo-workflow
description: Finish serious work properly - code, writing, research or analysis. Build in rounds, prove each with evidence, then adversarially try to break it. Runs SOLO (self-review) or MULTI (an independent reviewer that never saw you think). Ends in one verdict - SHIP, DRAFT or BLOCKED - and turns whatever went wrong into a durable rule, so the workflow gets better at YOUR work over time.
---

# The Konyo Workflow

A way of finishing work so that "done" means *checked*, not *finished typing*.

Work fails in three ways: it looked right and wasn't, it fixed one instance of a problem
that existed in five places, or nobody could tell afterwards whether it actually worked.
Every step below makes one of those harder.

**Shape:** read SCARS → understand → build in rounds → prove each round → adversarial
back-pass → one verdict → record the scar.

**Before Step 1, read `SCARS.md`.** It is short, and it is the only file here written by
experience rather than by someone guessing in advance what would go wrong.

---

## Rule 0 — one verdict, and it fails closed

**Every run ends with exactly one of these three words.** It fails closed: anything short of
proven-good reports as DRAFT or BLOCKED, never as SHIP-with-caveats.

| Verdict | Meaning |
|---|---|
| **SHIP** | Every applicable check passed *with evidence*. Safe to send, merge, publish, submit. |
| **DRAFT** | The work is sound but the bar was not fully met — usually missing proof, not missing quality. |
| **BLOCKED** | A real problem was found. Say what it is and what would unblock it. |

### What counts as "in scope" — the line that decides the verdict

Rule 0 forbids SHIP-with-caveats. Step 6 requires a *"What was NOT checked"* section.
Those look contradictory and are not, but only once scope is pinned:

**Scope is declared at Step 1 and cannot be narrowed once work begins.** Widening it
is free. Narrowing it needs the person who asked — otherwise "out of scope" becomes a
way to launder a known defect into a SHIP, which is the failure this rule exists to
stop.

| Situation | Verdict |
|---|---|
| A known, unfixed defect **inside** declared scope | **DRAFT** — or BLOCKED if it is a real problem. Never SHIP. |
| Something you **could not verify** (no access, no data, no environment) | SHIP is available. The boundary goes in "What was NOT checked". |
| Something genuinely **outside** declared scope | SHIP is available. Name it so nobody assumes it was covered. |

**The test, when the table does not settle it:** *if the reader knew this, would they
be surprised the verdict was SHIP?* If yes, it is not SHIP. That question resolves
the cases the table cannot, and it resolves them the safe way.

**Missing evidence is not a pass.** A check you could not run is `N/A` with the reason
stated. *"I can't check the numbers, I don't have the source data"* is a legitimate N/A.
*"It looks fine"* is a FAIL wearing a friendly face.

Never report SHIP to be agreeable. A wrong SHIP costs far more than an honest DRAFT.

---

## Step 1 — Understand before building

**Restate the goal in your own words** — that is what surfaces a misread of the request
itself. Include: what "done" looks like **concretely**, what is explicitly **out of
scope**, and anything **ambiguous**. Ask about the ambiguity now; a wrong assumption is
cheapest to fix here.

**Say what is in scope and what is not, explicitly.** That declaration is what Rule 0's
verdict table reads later, and it cannot be narrowed once you start — so draw it now,
honestly, while you have nothing to protect.

**The short path needs BOTH conditions: small *and* low-stakes.** If the request is one
small, clearly-specified, low-stakes change, say so, keep the restatement to a single
line and run one round.

⚠ **Small is not the same as cheap to get wrong.** A one-line production config change,
a price, a permission, a published correction — each is a two-minute edit and none of
them is low-stakes. Size measures the diff; stakes measure what happens if it is wrong,
and **only stakes decide the ceremony.** When they disagree, stakes win.

**Ceremony proportional to stakes** — a full workflow on a genuinely trivial fix wastes
the person's time and they will stop using this. But that cuts one way only: cheap work
gets the short path, expensive work does not get it for being short.

---

## Step 2 — Build in rounds, one theme per round

A round is a set of changes that belong together and can be judged together. An unrelated
cleanup mixed into a round makes it impossible to evaluate and impossible to undo.

**Change only what was asked for.** No drive-by improvements, renames, reformatting or
"while I was in there" tidying. If you notice something else wrong, *say so and leave it*.
An unrequested change is indistinguishable from a mistake to whoever reviews it next, and
it is why a one-line fix arrives as a forty-line diff nobody can check.

---

## Step 3 — Prove the round

State what you checked **with the actual result**:

**Description is not proof.** "I updated the totals" describes. "The totals now read
4,812 and sum to the line items, which they did not before" proves.

**Give the before, not just the after.** "No errors remain" measures nothing if there were
zero errors before you started.

**Check the thing, not a proxy.** If the goal is "the link works", the proof is that the
link resolves — not that the link text looks right.

**Sweep the class.** Fixed a problem? Find the same shape everywhere and fix every
instance, or list the ones you deliberately left and why. Fixing only the one in front of
you is how the same mistake ships three times.

**Finish the sweep you print.** If you list places to check, check *all* of them. A
half-worked list is worse than no list because it looks like diligence. (Real failure: a
sweep flagged fourteen files, eight got checked, and one of the six skipped was broken in
exactly the way the sweep was looking for.)

**Distrust a check that passes.** The dangerous one is not the failing check but the one
that *passes for the wrong reason* — anything written to expect the old, incorrect answer
keeps passing for as long as the mistake survives, and looks like coverage throughout. So
when two checks on the same thing disagree, do not assume the failing one is wrong.
**That contradiction is the signal** — usually one of them was written against a truth that
has since changed, and the other has been quietly holding the error in place.

**Kill the stale claim.** Changed how something behaves? Correct everything that
*describes* the old behaviour — comments, instructions, a summary, a heading — in the same
round. Two places giving different answers is worse than one wrong answer, because nothing
catches it.

---

## Step 4 — The third eye: an adversarial back-pass

Stop building. Try to **break what you made.** Read it as if you had never seen it and
someone is asking you to approve it — not to admire it.

Four lenses, **one at a time**, because each catches what the others miss:

1. **Correctness** — is anything actually *wrong*? Numbers, logic, facts, names, dates,
   claims.
2. **Completeness** — what is *missing*? A case not handled, a question not answered, a
   section promised and never written.
3. **Blast radius** — what does this affect that nobody listed? What breaks downstream?
   How would someone undo it?
4. **The embarrassment test** — what is the first thing the most demanding reader would
   object to? Name it; fixing is Step 5.

> **You are being asked for analysis, not agreement** — and equally, do **not** manufacture
> a problem to look useful. State the strongest case that this work is wrong, then the
> strongest case that it is right, and say which you believe and why. If you cannot judge
> something on the evidence available, say exactly that and **name what you would need**.
> *"I can't verify this — I'd need X"* is a real answer, worth more than a confident guess.

### ⚠ The known weakness

Run in the same conversation, this is **the same model reviewing its own work** — a
genuine limitation, not a formality. Its blind spots are *correlated*: it finds the errors
it was already equipped to notice and misses the ones built into how it approached the
problem. Better than no review, weaker than an independent one. Step 4b is the fix.

Three things make it less weak, and they are required:

- **Re-read the actual artifact** — the real text, the real numbers, the real output. Most
  self-review failures review the intention instead of the result.
- **Default to refuted when uncertain.** Treat a maybe-problem as a problem and
  investigate. Uncertainty resolved as "probably fine" is how everything ships.
- **Name what you could not check.** End the pass with an **explicit list** of what remains
  unverified. That list is the honest boundary of this workflow's confidence, and the human
  reading it can decide whether it matters.

**When it genuinely matters, ask a human — or a different AI — to look.**

---

## Step 4b — SOLO or MULTI: how independent the review was

Correlated blind spots do not yield to trying harder in the same breath. They yield to
**changing what the reviewer knows.** These modes differ in independence, not effort.

**SOLO** — Step 4 in this conversation. The default, and genuinely useful: most defects are
ordinary and a disciplined re-read finds them. Use it when being wrong is cheap **and
recoverable** — a draft, an internal note, an experiment, anything you will look at again
before it matters.

**MULTI** — the review happens somewhere that **never saw the building.** Use it when being
wrong is expensive: client-facing, published, sent to many people, spending money, or
embarrassing in public. A reviewer who watched you reason is already persuaded by your
reasoning; one that sees only the artifact has to be convinced by the artifact — the actual
test.

### The ladder — once you have chosen MULTI, use the highest rung available

(Choosing between SOLO and MULTI is the paragraph above; this table is only about how to run
a MULTI you have already decided on. Having a subagent available does not make MULTI
mandatory.)

| Rung | What it removes |
|---|---|
| **1. A different model family** | Contamination, and blind spots that sit in different places. The strongest MULTI. Name the model. |
| **2. A fresh subagent / agent task** | Most of the contamination — no manual step where this exists (Claude Code, Cowork, Agent SDK). Two caveats: *you* write its prompt, so contamination goes down by discipline rather than being removed by the mechanism; and a subagent may run a different, often smaller model than yours, so name what it was if you can find out. |
| **3. A new conversation**, pasted by hand | Same as rung 2, more effort, no prompt-authoring advantage lost. The fallback in chat-only Claude. |
| **4. Same conversation** | Nothing. This is SOLO — call it SOLO. |

**Rung 3 means a new conversation, not a new message.** A fresh message in this thread still
has all of the building in its context and buys nothing. And MULTI happens *after* Steps 1-3
are finished — you review an artifact, not a work in progress.

**The reviewer gets exactly four things:** the artifact, the original request, the four
lenses, and one question — *would you approve this, and what is the strongest argument that
it is wrong?* Nothing about *how you built it*: not your plan, your reasoning, "here's what I
was going for", or your verdict. Those are exactly what would contaminate it. Bring the
findings to Step 5.

**MULTI is not "SOLO with more steps."** Reviewing in the same conversation and calling it
MULTI buys the ceremony, none of the independence, and a seal that claims something untrue.

> **Say which mode in the seal. "SOLO" is an honest answer, not a confession** — the
> dishonest answer is an unearned "MULTI".

**When it really matters,** add single-lens passes: one reading only for factual
correctness, one as the least sympathetic reader you can imagine. Separate passes beat one
combined pass, because a reviewer looking for everything drifts into looking for nothing.

---

## Step 5 — Fix, then re-prove

Everything the back-pass found gets fixed and **proven again**. A fix is done when the
failure no longer happens and you have said so with evidence — not when it was applied. If
a fix touches what an earlier round proved, that proof is stale. Redo it.

Set a ceiling **before** looping — three passes suits most work — then stop for one of
exactly three reasons, and **say which**:

| | |
|---|---|
| **PASSED** | The check succeeds. The only real success. |
| **CEILING** | Hit the limit, still failing, **and the failure kept changing.** Possibly converging — it needs more room than you allowed. |
| **STALLED** | The same failure **twice** running, unchanged. **Stop immediately.** |

Both of the last two mean "not fixed", and the difference is what they license. **Both stop
the loop and get reported** — the ceiling you set is the discipline, and drifting past it is
how "a few more passes" becomes an afternoon. What differs is what happens next: CEILING
means *another run is worth granting*, so either a human decides or you set a new ceiling
**deliberately, with the reason stated**. STALLED means *more passes buy nothing* — change
the approach, the assumption under it, or what you are checking, then start a fresh count.

**When stalled, do not raise the ceiling.** That is the instinct and it is wrong. Collapse
these two into "didn't work" and you will reliably spend the next hour on the version that
cannot work.

> ⚠ **Invisible trap.** A check that produces *no output* on failure makes every failed
> pass look identical whether you are progressing or not. Make it say something, or judge
> progress on the work itself. **Silence is not evidence of being stuck, or of progress.**

---

## Step 6 — Seal it

Report, briefly:

- **Verdict** — SHIP / DRAFT / BLOCKED, decided by Rule 0's scope table. A known
  unfixed defect inside declared scope is **never** SHIP, however well everything else
  was proven.
- **What changed** — plain language, what a reader would notice.
- **How it was proven** — checks and results.
- **What was NOT checked** — the honest boundary: what you could not verify, and what
  sat outside the scope declared at Step 1. This section explains a SHIP; it never
  rescues one.
- **How to undo it** — if it is that kind of work.
- **Stopped because** — PASSED / CEILING / STALLED, after how many passes.
- **Mode** — SOLO or MULTI, truthfully; if MULTI, which rung and what reviewed it.
- **Scars** — did an existing scar apply, and did you follow it? Did this run produce a
  new one? If yes, **print the scar block, ready to paste, including its EVIDENCE line**,
  offer the updated file, and say durability is unverified — never that it was saved. If
  no, say "no scar" — saying it out loud is what stops this step being quietly skipped
  forever.

Then stop. Do not append things you did not do and call them next steps unless asked.

---

## Step 7 — SCARS: turn what went wrong into something that cannot go wrong again

Everything above improves *this* work. This step is the only one that improves the **next**
work. A conversation ends and everything it learned dies with it; notes don't help, because
nobody re-reads their notes before starting. **A scar is a mistake converted into a rule
that loads itself.**

### Two layers, and the difference is authority

**FOUNDING RULES are yours** — written by hand, deliberately, at the top of `SCARS.md`.
Not lessons from a bug but the terms your work runs on ("never send a client a number I
haven't traced to source"). **Nothing learned may ever overwrite one.**

**LEARNED SCARS append below**, at lower authority on purpose: a rule extracted from one
bad afternoon should not weigh the same as one you chose while thinking clearly.

A fresh copy of `SCARS.md` may also carry a **CANDIDATES** block — proposed founding rules
that nobody has ratified. **It has no authority at all: not a founding rule, not a scar, and
not an "entry" for the purposes of the seal's scar question.** Ignore it when working.

**Mention once that it is waiting on RATIFICATION — not on being written.** The drafts
are already there; what has not happened is the person deciding which they believe,
rewriting those into FOUNDING RULES in their own words, and deleting the rest. Saying it
is "waiting to be filled in" describes the wrong gap and invites Claude to fill it,
which is the one thing that must not happen: a founding rule carrying someone's
authority has to be one they chose.

**Until they ratify, FOUNDING RULES is legitimately empty** and the run is proceeding on
this skill's steps alone. Say that once, plainly, rather than letting an unratified
CANDIDATES block read as though rules are in force.

### Recording one

When something went genuinely wrong — a real error, a wrong assumption, a thing that had
to be redone — write it in exactly this shape and add it to the LEARNED section:

```
WHAT BROKE   the summary quoted a number that was never in the source
COST         it went out to 40 people before anyone noticed
CAUGHT BY    re-reading the source, not re-reading my summary
RULE         every figure in a summary gets traced back to the sentence it came
             from, before the summary is finished
GUARD        Step 3's check list — added "every number traced to source"
EVIDENCE     the figure appeared in my draft and in no paragraph of the source;
             I searched all 14 pages before concluding that
```

**All six lines, every time.** The first three — WHAT BROKE, COST, CAUGHT BY — are the
diary. The last three are what make it a defence, and they are the three people skip:

- **RULE is an instruction, not a regret.** "Be more careful with numbers" is not a rule —
  nothing can follow it. "Trace every figure to the sentence it came from" is, because you
  can tell whether you did it.
- **GUARD names where the rule now lives** — a step here, a checklist line, a question you
  now always ask. If there genuinely isn't one, write `GUARD: NONE` **honestly**. An honest
  NONE is a hazard you know about; an invented guard reads as protected and is worse than
  nothing.
- **EVIDENCE names what in *this run* proved it** — what happened, not why it sounds
  sensible. This is the difference between a rule and a superstition. Without it, the
  workflow fills with confident restrictions nobody can trace, refusing things for reasons
  that were never true.

### Undoing one

**Copy `SCARS.md` to `SCARS.prev.md` before adding a scar** — or just keep the old text
somewhere for a day. A lesson from one confusing afternoon can be **wrong** — wrong cause,
or rule drawn too wide — and a wrong rule is worse than no rule because you will actually
follow it. Without a copy it is permanent; with one, undoing it takes ten seconds.
**Founding rules are untouched by this**; they change only by hand.

### Getting the scar into the file

**Always do all three of these, in order. Do not try to work out which case you are in.**

Three earlier versions of this passage asked you to classify the environment first —
local files, synced-and-ephemeral, or write-fails — and pick a branch. Two independent
reviews and one live trial reached the same conclusion: **the classification is not
decidable from inside the run.** The trial agent could not tell which case it was in,
did all of it anyway, and reported that the branching had bought nothing. So the
branch is gone. Doing all three costs one short block and a sentence.

1. **Print the scar block in the seal**, formatted and ready to paste. This is the only
   version that survives if everything else about the file handling goes wrong, and it
   costs almost nothing.

2. **Write the updated `SCARS.md` and offer it as a file.** If you can write to the
   skill folder, do — and copy the old text to `SCARS.prev.md` first, so a wrong lesson
   is undoable. If you cannot, hand the updated file over.

3. **Say plainly that durability is unverified**, in one sentence, every time.

⚠ **Reading the file back proves the WRITE, never the DURABILITY** — and that is the
whole reason step 3 exists. A write into a workspace that is discarded at the end of the
session succeeds, reads back correctly, and persists nothing. There is no check
available from inside the run that distinguishes that from a real save, so the honest
report is *"written; whether it persists depends on your setup — keep a copy."*

**Never say a scar was saved.** Say it was written and printed, and that saving it is
theirs to confirm. Skipping the paste loses the scar with nothing to warn you — the run
still looks successful — which is why the seal asks about the scar at all: it makes the
loss visible now rather than three months from now.

### Carving a new skill out of scars — the part that compounds

Watch for **three or more scars in the same territory** — not the same mistake three times
but the same *area*: three about numbers, three about client-email tone, three about one
system. That area is recurring work and has earned its own instructions:

1. **Write a sibling skill folder** named for the territory — `checking-figures`,
   `client-emails`, `monthly-report`.
2. **Put the rules in as procedure**, not warnings: steps, order, specific checks, the
   phrasing that worked, the trap that keeps catching you. Scars are raw material; the
   skill is the finished procedure.
3. **Name the scar each rule came from.** Recorded origins survive someone asking "do we
   still need this?"; a rule without one gets deleted by the first person tidying up, and
   then it happens again.
4. **Leave a pointer here**, so this skill loads the child in that territory.
5. **Delete those entries from `SCARS.md`.** Not housekeeping — the file stays short
   *because* things graduate out of it, and one nobody reads has failed like notes fail.

The loop: **work produces scars → scars accumulate into a territory → the territory becomes
a skill → the skill makes that work reliable → and the workflow is now better at your job
specifically, not at jobs in general.** Nobody can hand you that version; it can only be
grown.

---

## The checks — mark each PASS / FAIL / N/A-with-reason

Skip what does not apply, but **say you skipped it and why.** Silence reads as "passed".

**All work**

| Check | Question |
|---|---|
| Correct | Is it factually and logically right? |
| Complete | Does it cover everything asked, and nothing it shouldn't? |
| Evidence | Is each claim backed by something checkable? |
| Clarity | Would the intended reader understand it without you explaining? |
| Stale claims | Does anything still describe the old behaviour? |
| Reversible | Can this be undone, and is that written down? |
| Scars read | Did you read `SCARS.md` first, and did any entry apply? |
| Mode named | Does the seal say SOLO or MULTI, truthfully? |

**Code and technical work** *(mark N/A for writing, research or analysis)*

| Check | Question |
|---|---|
| Tests | Do tests exist for *this* change, and did they actually run? |
| Syntax | Does it parse / lint cleanly? |
| Security | Secrets, injection, permissions, unsafe defaults. |
| Reachability | Is every new thing actually *reached* by something? Dead code described as a feature is worse than a missing feature — nobody looks again. |
| Version + record | Version bumped, and change recorded where the project already records changes? |
| Rollback | Is the reverse path known? |

**On tests:** "the suite is green" is not evidence that *your* tests ran — prove they
executed, with a count before and after or the new test names in the output. And a test
that cannot fail proves nothing: if you strengthened a check, make sure the case it guards
against can actually occur, or you bought confidence without coverage.

---

## Scaling

| Situation | What to do |
|---|---|
| Small, clear, low stakes | One round, prove it, brief back-pass. Minutes. |
| Normal work | Full steps, one or two rounds, SOLO. |
| High stakes / irreversible / public | Full workflow, extra single-lens passes, MULTI at the highest rung available, and **say out loud** that an independent reviewer is recommended before it goes out. |

The person can override:

| They say | You do |
|---|---|
| "quick pass", "sanity check", "don't overthink it" | One round. Still check it, still give a verdict. |
| *(nothing)* | Judge from the stakes. |
| "be thorough", "this really matters", "go deep" | Every lens separately, artifact re-read twice with a gap, MULTI, and **state explicitly** that an independent human or a different AI should look before this goes out. |

**What "quick" may never do:** skip the verdict, hide an uncertainty, or report SHIP on
something unchecked. It reduces how *much* you examine, never how *honestly* you report
it. If a quick pass finds something serious, stop being quick and say so.

> **On `tiny`/`lean`/`max`:** those belong to a different tool, where they control how many
> parallel agents get spawned and how long a run takes. Honouring the word here would be
> theatre — a label controlling nothing. If someone asks for `max`, read it as "go deep" in
> the table above and say that is what you did. Depth and independence are the things that
> actually vary here.

---

## What this skill will not do

- Report success for work that was not done or not checked.
- Say SHIP when a required check has no evidence behind it.
- Hide an uncertainty to sound more confident.
- Expand the job beyond what was asked without saying so.
- Claim MULTI for a review that happened in the same conversation.

*Created by Konyo. The discipline is his. This version runs anywhere and requires no second
AI — it uses an independent reviewer when the stakes call for one and the environment has
one, and never claims that working alone is as good.*
